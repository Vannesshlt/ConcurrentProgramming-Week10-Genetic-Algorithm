//Chin Yi Jia  14057061
//Tan Hoi Leong 14052393

import java.util.concurrent.ThreadLocalRandom;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

//to create the chart
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;


public class GeneticAlgorithm {

	public static double globalBestFit = Double.MAX_VALUE, mutateValue = 1;
	public static int popSize, tourSize = 3, generation = 0, endGeneration, start, end, firstChildSecondPart,
					  secondChildFirstPart, reverseCutLine;
	public static Random rand = new Random();
    public static ArrayList<Double> minimumOfGeneration = new ArrayList<Double>();
	
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);

        //prompt user for population size
        do{
	        System.out.print("Enter population size: ");
	        try
	        {
	          popSize=reader.nextInt();
	        }
	        catch(InputMismatchException exception)
	        {
	          System.out.println("This is not an integer");
	          reader.nextLine();
	        }
        } while(popSize<=0);

        //prompt user to enter number of generation
        do{
	        System.out.print("Enter number of generation: ");
	        try
	        {
	          endGeneration=reader.nextInt();
	        }
	        catch(InputMismatchException exception)
	        {
	          System.out.println("This is not an integer");
	          reader.nextLine();
	        }
        } while(endGeneration<=0);

        //Prompt user to enter the starting range for the graph
        do{
	        System.out.print("Enter starting range for graph for viewing: ");
	        try
	        {
	          start=reader.nextInt();
	        }
	        catch(InputMismatchException exception)
	        {
	          System.out.println("This is not an integer");
	          start=-1;
	          reader.nextLine();
	        }
        } while(start<0 || start>=endGeneration);


        //Prompt user to enter the ending range for the graph
        do{
        	System.out.print("Enter ending range for graph for viewing: ");
	        try
	        {
	          end=reader.nextInt();
	        }
	        catch(InputMismatchException exception)
	        {
	          System.out.println("This is not an integer");
	          reader.nextLine();
	        }
        } while(end>endGeneration || end<=start);
        
        reader.close();

        double[][] population = new double[popSize][100];  //2D array of original population
        double[][] newPopulation = new double[population.length][100];  //2D array of new population
        double[] fitness = new double[population.length];   //fitness: minimum value of summation for each row
        
        generatePopulation(population);  //insert random values from -5.12 to 5.12 into 2D original population array
        
        do{
        	
	        evaluateFitness(population,fitness);  //value * value * (column+1)
	        
	        System.out.printf("Generation: %d, max: %f, min: %f, average: %f\n",
                    generation, findWorstFitness(fitness), findBestFitness(fitness), findAvg(fitness));
	        
	        crossPopulate(population, newPopulation, fitness);  //70% chance cross populate
	        mutate(newPopulation);  //1% mutation rate
	        changePopulation(population, newPopulation);  //replace the oldPopulation with the newPopulation
	        changeMutateValue();  //as the globalBestFit decrease, mutateValue decreases
	        
	        
        } while(generation++<endGeneration);
        
        System.out.printf("\nThe minimum value found is %f\n\n", globalBestFit);

        //to display the result in a chart
        LineChart_AWT chart = new LineChart_AWT(
        "Minimum value for each generations" ,
        "Minimum value for each generations");

        chart.pack( );
        RefineryUtilities.centerFrameOnScreen( chart );
        chart.setVisible( true );
    }


    //insert random values from -5.12 to 5.12 into 2D original population array
    public static void generatePopulation(double[][] population)
    {
        for(int row=0;row<population.length;row++)
        {
            for(int column=0;column<100;column++)
            {
                population[row][column] = ThreadLocalRandom.current().nextDouble(-5.12, 5.12);
            }
        }
    }

    //Each summation individual values obtained is deemed as individualFitness
    public static void evaluateFitness(double[][] population, double[] fitness)
    {
    	double individualFitness = 0;
        for(int row=0;row<population.length;row++)
        {
            for(int column=0;column<100-1;column++)
            {
                individualFitness +=(100*(population[row][column+1]-((population[row][column])*(population[row][column]))*(population[row][column+1]-((population[row][column])*(population[row][column])))))+((population[row][column]-1)*(population[row][column]-1));


            }
            fitness[row] = individualFitness;
        	individualFitness = 0;
       }
    }


  //The bigger the value of summation of individual fitness, the less fit the individual is
    public static double findWorstFitness(double[] fitness)
    {
    	double worstFit = Double.MIN_VALUE;
        for(int row=0;row<fitness.length;row++)
        {
        	if(worstFit<=fitness[row])
        	{
        		worstFit = fitness[row];	        	
        	}
        }
    	return worstFit;
    }


  //The smaller the value of summation of individual fitness, the more fit the individual is
    public static double findBestFitness(double[] fitness)
    {
    	double bestFit = Double.MAX_VALUE;
        for(int row=0;row<fitness.length;row++)
        {
        	if(bestFit>=fitness[row])
        	{
        		bestFit = fitness[row];	
        	}
        }
    	if(globalBestFit>=bestFit)
    	{
    		globalBestFit = bestFit;
    	}
    	
    	minimumOfGeneration.add(bestFit);
    	return bestFit;
    }


    //find the average fitness obtained in the population
    public static double findAvg(double[] fitness)
    {
    	double avg = 0;
    	for(int row=0;row<fitness.length;row++)
    	{
    		avg += fitness[row];
    	}
    	return (avg/fitness.length);
    }

    //3 individuals will be selected randomly
    //2 of the individuals with best fit will be selected based on tournament fight
    //2 winners will be inserted into tempArrOne and tempArrTwo
    public static void tournamentFight(double[][] population, double[] tempArrOne, double[] tempArrTwo, double[] fitness)
    {
    	double bestFitness = Double.MAX_VALUE;
        int[] tournament = new int[tourSize];
        tournament[0] = rand.nextInt(population.length);
    	for(int count=1;count<tournament.length;count++)
        {
    		tournament[count] = rand.nextInt(population.length);
    		if(tournament[count]==tournament[count-1])
    		{
    			count--;
    		}
	        
        }

        for(int count=0;count<tournament.length;count++)
        {
        	if(bestFitness>fitness[tournament[count]])
        	{
        		for(int x=0;x<100;x++)
        		{
        			tempArrOne[x] = population[tournament[count]][x];
        		}
        		bestFitness = fitness[tournament[count]];
        	}
        }
        
        bestFitness = Double.MAX_VALUE;
        tournament[0] = rand.nextInt(population.length);
        for(int count=1;count<tournament.length;count++)
        {
    		tournament[count] = rand.nextInt(population.length);
    		if(tournament[count]==tournament[count-1])
    		{
    			count--;
    		}
        }

        for(int count=0;count<tournament.length;count++)
        {
        	if(bestFitness>=fitness[tournament[count]])
        	{
        		for(int x=0;x<100;x++)
        		{
        			tempArrTwo[x] = population[tournament[count]][x];
        		}
        		bestFitness = fitness[tournament[count]];
        	}
        }
    }

    //70% cross populate rate
    //2 individuals are to cross over to generate two new children
    //the cutLine is determined randomly
    //30% rate that the two new children are identical to their parents
    public static void crossPopulate(double[][] population,double[][] newPopulation,double[] fitness)
    {
        double[] tempArrOne = new double[100];
        double[] tempArrTwo = new double[100];
        double[] newChildOne = new double[100];
        double[] newChildTwo = new double[100];
        int cutLine = 0, newPopSize = 0;
    	while(newPopSize<population.length)
        {
	        tournamentFight(population,tempArrOne,tempArrTwo,fitness);

        	if(rand.nextDouble()<0.7)
        	{
        		cutLine = rand.nextInt(100); 
        		firstChildSecondPart=cutLine; 
        		secondChildFirstPart=0;
        		reverseCutLine=100-cutLine; 
        		
        		for(int column=0;column<cutLine;column++)
        		{
        			newChildOne[column] = tempArrOne[column];
        		}
        		for(int column=cutLine;column<100;column++)
        		{
        			newChildOne[column] = tempArrTwo[column];
        		}
        		for(int column=0;column<reverseCutLine;column++)
        		{
        			newChildTwo[column]=tempArrOne[firstChildSecondPart++];
        		}
        		for(int column=reverseCutLine;column<100;column++)
        		{
        			newChildTwo[column]=tempArrTwo[secondChildFirstPart++];
        		}

    	        for(int column=0;column<100;column++)
    	        {
    	        	newPopulation[newPopSize][column] = newChildOne[column];
    	        }	
    	        newPopSize++;
    	        for(int column=0;column<100;column++)
    	        {
	        		newPopulation[newPopSize][column] = newChildTwo[column];
    	        }	
    	        newPopSize++;
        	}
        	else
        	{
    	        for(int column=0;column<100;column++)
    	        {
    	        	newPopulation[newPopSize][column] = tempArrOne[column];
    	        }	
    	        newPopSize++;
    	        for(int column=0;column<100;column++)
    	        {
	        		newPopulation[newPopSize][column] = tempArrTwo[column];
    	        }	
    	        newPopSize++;
        	}
        }
    }


    //1% mutation rate
    //The values in the new population are mutated by the mutateValue
    public static void mutate(double[][] newPopulation)
    {
    	double random = 0, temp = 0;
        for(int row=0;row<newPopulation.length;row++)
        {
        	for(int column=0;column<100;column++)
        	{
        		if(rand.nextDouble()<0.01)
        		{
                    //Returns a pseudorandom, uniformly distributed value between the
                    //-mutateValue (inclusive) and mutateValue (exclusive)
                    random = ThreadLocalRandom.current().nextDouble(-mutateValue, mutateValue);
        			temp = newPopulation[row][column];
        			newPopulation[row][column] = newPopulation[row][column]+random;
	                if(newPopulation[row][column]<-5.12 || newPopulation[row][column]>5.12)
	                {
	                	newPopulation[row][column] = temp;
	                	column--;
	                }
        		}
        	}
        } 
    }
    

    //the old population is replaced by the new population
    public static void changePopulation(double[][] population, double[][] newPopulation)
    {
        for(int row=0;row<population.length;row++)
        {
            for(int column=0;column<100;column++)
            {
            	population[row][column] = newPopulation[row][column];
            }
        }
    }


    //the mutate value decreases as the maximum and minimum values decrease
    public static void changeMutateValue()
    {
        if(generation%50==0)
        {
        	if(mutateValue>=0.2)
        	{
        		mutateValue -= 0.1;
        	}
        	else if(mutateValue>=0.02)
        	{
        		mutateValue -= 0.03;
        	}
        	else if(mutateValue>=0.002)
        	{
        		mutateValue -= 0.003;
        	}
        }
    }
    
}


//to create a graph
class LineChart_AWT extends ApplicationFrame
{
   /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public LineChart_AWT( String applicationTitle , String chartTitle )
   {
      super(applicationTitle);
      JFreeChart lineChart = ChartFactory.createLineChart(
         chartTitle,
         "Number of Generations","Minimum Value",
         createDataset(),
         PlotOrientation.VERTICAL,
         true,true,false);
         
      ChartPanel chartPanel = new ChartPanel( lineChart );
      chartPanel.setPreferredSize( new java.awt.Dimension( 560 , 367 ) );
      setContentPane( chartPanel );
   }

   private DefaultCategoryDataset createDataset( )
   {
      DefaultCategoryDataset dataset = new DefaultCategoryDataset( );
      for(int row = GeneticAlgorithm.start; row < GeneticAlgorithm.end; row++){
          dataset.addValue( GeneticAlgorithm.minimumOfGeneration.get(row) , "minimum" , String.valueOf(row+1));
      }
      return dataset;
   }
}


